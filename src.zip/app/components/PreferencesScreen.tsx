import { useState } from 'react';
import { Pizza, Coffee, Salad, Drumstick, Fish, IceCream, DollarSign, Store, UtensilsCrossed, Wine, Home, Sparkles, ChevronRight, ArrowLeft } from 'lucide-react';

interface PreferencesScreenProps {
  onComplete: (preferences: UserPreferences) => void;
}

interface UserPreferences {
  foodType: string[];
  budget: string;
  placeType: string[];
}

const foodTypes = [
  { id: 'italian', label: 'Italiana', icon: Pizza },
  { id: 'mexican', label: 'Mexicana', icon: Drumstick },
  { id: 'asian', label: 'Asiática', icon: Fish },
  { id: 'vegetarian', label: 'Vegetariana', icon: Salad },
  { id: 'cafe', label: 'Café', icon: Coffee },
  { id: 'dessert', label: 'Postres', icon: IceCream },
];

const budgetOptions = [
  { id: 'low', label: 'Económico', symbol: '$', description: 'Menos de $15' },
  { id: 'medium', label: 'Moderado', symbol: '$$', description: '$15 - $40' },
  { id: 'high', label: 'Premium', symbol: '$$$', description: 'Más de $40' },
];

const placeTypes = [
  { id: 'casual', label: 'Casual', icon: Store },
  { id: 'formal', label: 'Formal', icon: UtensilsCrossed },
  { id: 'bar', label: 'Bar/Pub', icon: Wine },
  { id: 'familyfriendly', label: 'Familiar', icon: Home },
];

export function PreferencesScreen({ onComplete }: PreferencesScreenProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedFoodTypes, setSelectedFoodTypes] = useState<string[]>([]);
  const [selectedBudget, setSelectedBudget] = useState<string>('');
  const [selectedPlaceTypes, setSelectedPlaceTypes] = useState<string[]>([]);

  const toggleFoodType = (id: string) => {
    setSelectedFoodTypes(prev =>
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const togglePlaceType = (id: string) => {
    setSelectedPlaceTypes(prev =>
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete preferences
      onComplete({
        foodType: selectedFoodTypes,
        budget: selectedBudget,
        placeType: selectedPlaceTypes,
      });
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canContinue = () => {
    if (currentStep === 1) return selectedFoodTypes.length > 0;
    if (currentStep === 2) return selectedBudget !== '';
    if (currentStep === 3) return selectedPlaceTypes.length > 0;
    return false;
  };

  const getPollyMessage = () => {
    if (currentStep === 1) return "¡Hola! Soy Polly 🐙. Ayúdame a conocerte mejor. ¿Qué tipo de comida te gusta?";
    if (currentStep === 2) return "¡Perfecto! Ahora dime, ¿cuál es tu presupuesto preferido?";
    if (currentStep === 3) return "¡Genial elección! Por último, ¿qué tipo de ambiente prefieres?";
    return "";
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50 via-white to-white">
      {/* Header with back button */}
      {currentStep > 1 && (
        <div className="absolute top-6 left-6 z-10">
          <button
            onClick={handleBack}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/80 bg-white shadow-md transition-all"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      )}

      {/* Octopus Character - Always visible */}
      <div className="flex flex-col items-center pt-8 pb-4 px-6">
        <div className="relative mb-4">
          <div className="w-28 h-28 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full relative flex items-center justify-center shadow-lg">
            {/* Octopus face */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {/* Eyes */}
              <div className="flex gap-3 mb-1">
                <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center">
                  <div className="w-2.5 h-2.5 bg-gray-800 rounded-full"></div>
                </div>
                <div className="w-5 h-5 bg-white rounded-full flex items-center justify-center">
                  <div className="w-2.5 h-2.5 bg-gray-800 rounded-full"></div>
                </div>
              </div>
              {/* Smile */}
              <div className="w-7 h-3.5 border-b-4 border-white rounded-b-full"></div>
            </div>
          </div>
          
          {/* Tentacles */}
          <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="w-2.5 h-7 bg-gradient-to-b from-purple-600 to-purple-500 rounded-full"
                style={{
                  transform: `rotate(${(i - 2.5) * 8}deg)`,
                  transformOrigin: 'top center'
                }}
              ></div>
            ))}
          </div>

          {/* Sparkles */}
          <Sparkles className="absolute -top-2 -right-2 w-7 h-7 text-yellow-400 fill-current animate-pulse" />
        </div>

        {/* Speech Bubble */}
        <div className="relative bg-white rounded-3xl shadow-lg p-4 mt-6 border-2 border-purple-200 max-w-sm">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-white border-l-2 border-t-2 border-purple-200 rotate-45"></div>
          <p className="text-center text-gray-700 text-sm leading-relaxed font-medium">
            {getPollyMessage()}
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex gap-2 mt-6">
          {[1, 2, 3].map((step) => (
            <div
              key={step}
              className={`h-2 rounded-full transition-all ${
                step === currentStep
                  ? 'w-8 bg-purple-600'
                  : step < currentStep
                  ? 'w-2 bg-purple-400'
                  : 'w-2 bg-gray-300'
              }`}
            ></div>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {/* Step 1: Food Type */}
        {currentStep === 1 && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1 text-center">
              Tipo de comida
            </h3>
            <p className="text-sm text-gray-500 mb-6 text-center">Selecciona tus favoritas</p>
            
            <div className="grid grid-cols-2 gap-3">
              {foodTypes.map((food) => {
                const Icon = food.icon;
                const isSelected = selectedFoodTypes.includes(food.id);
                return (
                  <button
                    key={food.id}
                    onClick={() => toggleFoodType(food.id)}
                    className={`
                      flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all
                      ${isSelected 
                        ? 'border-purple-500 bg-purple-50 shadow-lg scale-105' 
                        : 'border-gray-200 bg-white hover:border-purple-300'
                      }
                    `}
                  >
                    <Icon className={`w-10 h-10 mb-2 ${isSelected ? 'text-purple-600' : 'text-gray-400'}`} />
                    <span className={`text-sm font-medium ${isSelected ? 'text-purple-700' : 'text-gray-700'}`}>
                      {food.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2: Budget */}
        {currentStep === 2 && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1 text-center">
              Presupuesto
            </h3>
            <p className="text-sm text-gray-500 mb-6 text-center">¿Cuánto quieres gastar?</p>
            
            <div className="space-y-3 max-w-sm mx-auto">
              {budgetOptions.map((budget) => {
                const isSelected = selectedBudget === budget.id;
                return (
                  <button
                    key={budget.id}
                    onClick={() => setSelectedBudget(budget.id)}
                    className={`
                      w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all
                      ${isSelected 
                        ? 'border-purple-500 bg-purple-50 shadow-lg' 
                        : 'border-gray-200 bg-white hover:border-purple-300'
                      }
                    `}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`
                        w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg
                        ${isSelected ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-400'}
                      `}>
                        {budget.symbol}
                      </div>
                      <div className="text-left">
                        <div className={`font-semibold ${isSelected ? 'text-purple-700' : 'text-gray-700'}`}>
                          {budget.label}
                        </div>
                        <div className="text-sm text-gray-500">{budget.description}</div>
                      </div>
                    </div>
                    <div className={`
                      w-6 h-6 rounded-full border-2 flex items-center justify-center
                      ${isSelected ? 'border-purple-500 bg-purple-500' : 'border-gray-300'}
                    `}>
                      {isSelected && (
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 3: Place Type */}
        {currentStep === 3 && (
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1 text-center">
              Tipo de lugar
            </h3>
            <p className="text-sm text-gray-500 mb-6 text-center">Ambiente preferido</p>
            
            <div className="grid grid-cols-2 gap-3">
              {placeTypes.map((place) => {
                const Icon = place.icon;
                const isSelected = selectedPlaceTypes.includes(place.id);
                return (
                  <button
                    key={place.id}
                    onClick={() => togglePlaceType(place.id)}
                    className={`
                      flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all
                      ${isSelected 
                        ? 'border-purple-500 bg-purple-50 shadow-lg scale-105' 
                        : 'border-gray-200 bg-white hover:border-purple-300'
                      }
                    `}
                  >
                    <Icon className={`w-10 h-10 mb-2 ${isSelected ? 'text-purple-600' : 'text-gray-400'}`} />
                    <span className={`text-sm font-medium ${isSelected ? 'text-purple-700' : 'text-gray-700'}`}>
                      {place.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Action */}
      <div className="p-6 border-t border-gray-100 bg-white">
        <button
          onClick={handleNext}
          disabled={!canContinue()}
          className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl hover:from-purple-600 hover:to-purple-700 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-lg disabled:active:scale-100 flex items-center justify-center gap-2"
        >
          {currentStep < 3 ? (
            <>
              Siguiente
              <ChevronRight className="w-5 h-5" />
            </>
          ) : (
            'Ver recomendaciones'
          )}
        </button>
      </div>
    </div>
  );
}