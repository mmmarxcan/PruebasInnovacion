import { useState, useRef, useEffect } from 'react';
import { MapPin, SlidersHorizontal, Locate, Star, DollarSign, Navigation, Settings, LogOut, ChevronUp, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MapScreenProps {
  preferences: {
    foodType: string[];
    budget: string;
    placeType: string[];
  };
  onGoToPreferences: () => void;
  onLogout: () => void;
}

interface Restaurant {
  id: number;
  name: string;
  type: string;
  rating: number;
  priceLevel: string;
  distance: string;
  address: string;
  lat: number;
  lng: number;
  image: string;
}

const mockRestaurants: Restaurant[] = [
  {
    id: 1,
    name: "La Trattoria Bella",
    type: "Italiana",
    rating: 4.8,
    priceLevel: "$$",
    distance: "0.5 km",
    address: "Calle Principal 123",
    lat: 40.7128,
    lng: -74.0060,
    image: "https://images.unsplash.com/photo-1722587561829-8a53e1935e20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpdGFsaWFuJTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDF8fHx8MTc3MDIwOTY5MHww&ixlib=rb-4.1.0&q=80&w=400"
  },
  {
    id: 2,
    name: "Tacos El Güero",
    type: "Mexicana",
    rating: 4.6,
    priceLevel: "$",
    distance: "0.8 km",
    address: "Av. Reforma 456",
    lat: 40.7138,
    lng: -74.0070,
    image: "https://images.unsplash.com/photo-1666307551254-eacbfaff5369?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZXhpY2FuJTIwdGFjbyUyMHJlc3RhdXJhbnR8ZW58MXx8fHwxNzcwMjY0ODI1fDA&ixlib=rb-4.1.0&q=80&w=400"
  },
  {
    id: 3,
    name: "Sushi Zen",
    type: "Asiática",
    rating: 4.9,
    priceLevel: "$$$",
    distance: "1.2 km",
    address: "Plaza Central 789",
    lat: 40.7118,
    lng: -74.0050,
    image: "https://images.unsplash.com/photo-1634881091116-1876b8c2b414?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMHN1c2hpJTIwcmVzdGF1cmFudHxlbnwxfHx8fDE3NzAyNjQ4MjZ8MA&ixlib=rb-4.1.0&q=80&w=400"
  },
  {
    id: 4,
    name: "Green Garden",
    type: "Vegetariana",
    rating: 4.7,
    priceLevel: "$$",
    distance: "0.3 km",
    address: "Paseo Verde 321",
    lat: 40.7148,
    lng: -74.0065,
    image: "https://images.unsplash.com/photo-1643750182373-b4a55a8c2801?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFyaWFuJTIwc2FsYWQlMjBib3dsfGVufDF8fHx8MTc3MDIyNDQxOHww&ixlib=rb-4.1.0&q=80&w=400"
  },
  {
    id: 5,
    name: "Café Bohème",
    type: "Café",
    rating: 4.5,
    priceLevel: "$",
    distance: "0.6 km",
    address: "Calle Artista 654",
    lat: 40.7108,
    lng: -74.0055,
    image: "https://images.unsplash.com/photo-1739723745132-97df9db49db2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwY2FmZSUyMGludGVyaW9yfGVufDF8fHx8MTc3MDI2NDgyNnww&ixlib=rb-4.1.0&q=80&w=400"
  },
  {
    id: 6,
    name: "Sweet Dreams",
    type: "Postres",
    rating: 4.9,
    priceLevel: "$$",
    distance: "1.0 km",
    address: "Boulevard Dulce 987",
    lat: 40.7158,
    lng: -74.0045,
    image: "https://images.unsplash.com/photo-1496890607984-d27fca8a68ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW5jeSUyMGRlc3NlcnQlMjBwYXN0cnl8ZW58MXx8fHwxNzcwMjY0ODI3fDA&ixlib=rb-4.1.0&q=80&w=400"
  },
];

export function MapScreen({ preferences, onGoToPreferences, onLogout }: MapScreenProps) {
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [mapCenter, setMapCenter] = useState({ lat: 40.7128, lng: -74.0060 });
  const [showBottomSheet, setShowBottomSheet] = useState(true);
  const mapRef = useRef<HTMLDivElement>(null);

  const centerOnUser = () => {
    // Simulate centering on user location
    setMapCenter({ lat: 40.7128, lng: -74.0060 });
  };

  const handleMarkerClick = (restaurant: Restaurant) => {
    setSelectedRestaurant(restaurant);
    setShowBottomSheet(true);
  };

  return (
    <div className="h-full flex flex-col bg-white relative">
      {/* Map Container */}
      <div 
        ref={mapRef}
        className="flex-1 relative bg-gradient-to-br from-blue-50 to-green-50"
        style={{
          backgroundImage: `
            linear-gradient(90deg, rgba(226, 232, 240, 0.3) 1px, transparent 1px),
            linear-gradient(rgba(226, 232, 240, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px'
        }}
      >
        {/* Map Markers */}
        {mockRestaurants.map((restaurant, index) => {
          const isSelected = selectedRestaurant?.id === restaurant.id;
          // Position markers in a scattered pattern
          const positions = [
            { top: '30%', left: '40%' },
            { top: '50%', left: '60%' },
            { top: '45%', left: '25%' },
            { top: '65%', left: '45%' },
            { top: '35%', left: '70%' },
            { top: '55%', left: '35%' },
          ];
          const position = positions[index] || { top: '50%', left: '50%' };
          
          return (
            <button
              key={restaurant.id}
              onClick={() => handleMarkerClick(restaurant)}
              className="absolute transform -translate-x-1/2 -translate-y-full transition-all hover:scale-110"
              style={position}
            >
              <div className={`
                relative flex flex-col items-center
                ${isSelected ? 'scale-125' : ''}
              `}>
                <div className={`
                  px-3 py-1.5 rounded-full shadow-lg font-medium text-xs whitespace-nowrap mb-1
                  ${isSelected 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-white text-gray-800 border border-gray-200'
                  }
                `}>
                  {restaurant.name}
                </div>
                <div className={`
                  w-8 h-8 rounded-full shadow-lg flex items-center justify-center
                  ${isSelected ? 'bg-emerald-600' : 'bg-red-500'}
                `}>
                  <MapPin className="w-5 h-5 text-white fill-current" />
                </div>
              </div>
            </button>
          );
        })}

        {/* Top Action Buttons */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start z-10">
          {/* Filters Button */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-white rounded-2xl px-4 py-3 shadow-lg flex items-center gap-2 hover:bg-gray-50 transition-colors"
          >
            <SlidersHorizontal className="w-5 h-5 text-gray-700" />
            <span className="font-medium text-gray-700">Filtros</span>
          </button>

          {/* Menu Button */}
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="bg-white rounded-full w-12 h-12 shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
          >
            <Settings className="w-6 h-6 text-gray-700" />
          </button>
        </div>

        {/* Center Location Button */}
        <button
          onClick={centerOnUser}
          className="absolute bottom-32 right-4 z-10 bg-white rounded-full w-12 h-12 shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
        >
          <Locate className="w-6 h-6 text-emerald-600" />
        </button>

        {/* Menu Dropdown */}
        {showMenu && (
          <div className="absolute top-20 right-4 z-20 bg-white rounded-2xl shadow-2xl overflow-hidden w-56">
            <button
              onClick={() => {
                setShowMenu(false);
                onGoToPreferences();
              }}
              className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors border-b border-gray-100"
            >
              <SlidersHorizontal className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700 font-medium">Preferencias</span>
            </button>
            <button
              onClick={() => {
                setShowMenu(false);
                onLogout();
              }}
              className="w-full px-4 py-3 flex items-center gap-3 hover:bg-gray-50 transition-colors"
            >
              <LogOut className="w-5 h-5 text-red-500" />
              <span className="text-red-500 font-medium">Cerrar sesión</span>
            </button>
          </div>
        )}

        {/* Filters Panel */}
        {showFilters && (
          <div className="absolute top-20 left-4 right-4 z-20 bg-white rounded-2xl shadow-2xl p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-800">Filtrar por</h3>
              <button onClick={() => setShowFilters(false)}>
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {preferences.foodType.map((type) => (
                  <span key={type} className="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">
                    {type}
                  </span>
                ))}
              </div>
              <div className="text-sm text-gray-600">
                Presupuesto: <span className="font-medium">{preferences.budget}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Sheet with Restaurant List */}
      {showBottomSheet && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl shadow-2xl z-20 max-h-[45%] flex flex-col">
          {/* Handle */}
          <div className="flex justify-center pt-3 pb-2">
            <div className="w-12 h-1.5 bg-gray-300 rounded-full"></div>
          </div>

          {/* Header */}
          <div className="px-6 pb-3 border-b border-gray-100">
            <h3 className="font-bold text-lg text-gray-800">
              Restaurantes cercanos
            </h3>
            <p className="text-sm text-gray-500">{mockRestaurants.length} lugares encontrados</p>
          </div>

          {/* Restaurant List */}
          <div className="flex-1 overflow-y-auto px-6 py-4">
            <div className="space-y-3">
              {mockRestaurants.map((restaurant) => (
                <button
                  key={restaurant.id}
                  onClick={() => handleMarkerClick(restaurant)}
                  className={`
                    w-full flex gap-3 p-3 rounded-2xl transition-all hover:bg-gray-50
                    ${selectedRestaurant?.id === restaurant.id ? 'bg-emerald-50 border-2 border-emerald-500' : 'border-2 border-transparent'}
                  `}
                >
                  <ImageWithFallback
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-20 h-20 object-cover rounded-xl flex-shrink-0"
                  />
                  <div className="flex-1 text-left min-w-0">
                    <h4 className="font-semibold text-gray-800 truncate">{restaurant.name}</h4>
                    <p className="text-sm text-gray-500">{restaurant.type}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium text-gray-700">{restaurant.rating}</span>
                      </div>
                      <span className="text-sm text-gray-500">{restaurant.priceLevel}</span>
                      <span className="text-sm text-gray-500">{restaurant.distance}</span>
                    </div>
                  </div>
                  <Navigation className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-1" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
