import { Mail, Sparkles, ArrowRight, X } from 'lucide-react';

interface LoginPromptScreenProps {
  onLogin: () => void;
  onSkip: () => void;
}

export function LoginPromptScreen({ onLogin, onSkip }: LoginPromptScreenProps) {
  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50 via-white to-white relative">
      {/* Skip Button */}
      <button
        onClick={onSkip}
        className="absolute top-6 right-6 z-10 w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
      >
        <X className="w-6 h-6 text-gray-500" />
      </button>

      {/* Octopus Character */}
      <div className="flex flex-col items-center pt-16 pb-6 px-6">
        <div className="relative mb-6">
          <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full relative flex items-center justify-center shadow-lg">
            {/* Octopus face - excited */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {/* Eyes - sparkly */}
              <div className="flex gap-4 mb-2">
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center relative">
                  <div className="w-3 h-3 bg-gray-800 rounded-full"></div>
                  <Sparkles className="absolute -top-1 -right-1 w-3 h-3 text-yellow-300 fill-current" />
                </div>
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center relative">
                  <div className="w-3 h-3 bg-gray-800 rounded-full"></div>
                  <Sparkles className="absolute -top-1 -right-1 w-3 h-3 text-yellow-300 fill-current" />
                </div>
              </div>
              {/* Big smile */}
              <div className="w-10 h-5 border-b-4 border-white rounded-b-full"></div>
            </div>
          </div>
          
          {/* Tentacles - waving */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="w-3 h-8 bg-gradient-to-b from-purple-600 to-purple-500 rounded-full"
                style={{
                  transform: `rotate(${(i - 2.5) * 10}deg)`,
                  transformOrigin: 'top center'
                }}
              ></div>
            ))}
          </div>

          {/* Multiple Sparkles */}
          <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-400 fill-current animate-pulse" />
          <Sparkles className="absolute -top-1 -left-3 w-6 h-6 text-yellow-300 fill-current animate-pulse delay-100" style={{ animationDelay: '0.5s' }} />
        </div>

        {/* Main Message */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-3">
            ¡Casi listo! 🎉
          </h2>
          <div className="relative bg-white rounded-3xl shadow-lg p-5 border-2 border-purple-200 max-w-sm mx-auto">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-white border-l-2 border-t-2 border-purple-200 rotate-45"></div>
            <p className="text-gray-700 leading-relaxed text-sm">
              ¡Ya conozco tus gustos! Para una{' '}
              <span className="font-bold text-purple-600">mejor experiencia</span>, 
              guarda tus preferencias creando una cuenta.
            </p>
          </div>
        </div>

        {/* Benefits */}
        <div className="w-full max-w-sm space-y-3 mb-8">
          {[
            { icon: '💾', text: 'Guarda tus preferencias' },
            { icon: '⭐', text: 'Favoritos y reseñas' },
            { icon: '📍', text: 'Historial de lugares visitados' },
          ].map((benefit, index) => (
            <div
              key={index}
              className="flex items-center gap-3 bg-white rounded-2xl p-4 border border-purple-100 shadow-sm"
            >
              <div className="text-2xl">{benefit.icon}</div>
              <span className="text-gray-700 font-medium">{benefit.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Actions */}
      <div className="mt-auto p-6 space-y-3">
        <button
          onClick={onLogin}
          className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl hover:from-purple-600 hover:to-purple-700 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
        >
          <Mail className="w-5 h-5" />
          Crear cuenta o iniciar sesión
        </button>
        
        <button
          onClick={onSkip}
          className="w-full bg-white border-2 border-gray-200 text-gray-700 py-4 rounded-2xl font-semibold hover:bg-gray-50 hover:border-gray-300 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
        >
          Continuar sin cuenta
          <ArrowRight className="w-5 h-5" />
        </button>
        
        <p className="text-xs text-gray-500 text-center pt-2">
          Podrás crear tu cuenta en cualquier momento desde el menú
        </p>
      </div>
    </div>
  );
}
