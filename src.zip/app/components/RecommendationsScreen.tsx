import { useState } from 'react';
import { Star, MapPin, DollarSign, CheckCircle2, Sparkles } from 'lucide-react';

interface RecommendationsScreenProps {
  onContinue: (selectedRestaurants: number[]) => void;
  preferences: {
    foodType: string[];
    budget: string;
    placeType: string[];
  };
}

interface RecommendedRestaurant {
  id: number;
  name: string;
  type: string;
  rating: number;
  priceLevel: string;
  description: string;
  reason: string;
}

const recommendedRestaurants: RecommendedRestaurant[] = [
  {
    id: 1,
    name: "La Trattoria Bella",
    type: "Italiana",
    rating: 4.8,
    priceLevel: "$$",
    description: "Auténtica cocina italiana con pasta fresca hecha a mano",
    reason: "Perfecta para comida italiana casual"
  },
  {
    id: 2,
    name: "Tacos El Güero",
    type: "Mexicana",
    rating: 4.6,
    priceLevel: "$",
    description: "Los mejores tacos al pastor de la ciudad",
    reason: "Económico y muy bien valorado"
  },
  {
    id: 3,
    name: "Sushi Zen",
    type: "Asiática",
    rating: 4.9,
    priceLevel: "$$$",
    description: "Sushi premium con ingredientes importados",
    reason: "Experiencia única de sushi"
  },
  {
    id: 4,
    name: "Green Garden",
    type: "Vegetariana",
    rating: 4.7,
    priceLevel: "$$",
    description: "Opciones vegetarianas creativas y saludables",
    reason: "Ideal para opciones saludables"
  },
];

export function RecommendationsScreen({ onContinue, preferences }: RecommendationsScreenProps) {
  const [selectedRestaurants, setSelectedRestaurants] = useState<number[]>([]);

  const toggleRestaurant = (id: number) => {
    setSelectedRestaurants(prev =>
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const handleContinue = () => {
    onContinue(selectedRestaurants);
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50 via-white to-white">
      {/* Header with Octopus */}
      <div className="flex flex-col items-center pt-12 pb-6 px-6">
        {/* Octopus Character */}
        <div className="relative mb-4">
          <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full relative flex items-center justify-center shadow-lg">
            {/* Octopus face */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              {/* Eyes */}
              <div className="flex gap-4 mb-2">
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-gray-800 rounded-full"></div>
                </div>
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-gray-800 rounded-full"></div>
                </div>
              </div>
              {/* Smile */}
              <div className="w-8 h-4 border-b-4 border-white rounded-b-full"></div>
            </div>
          </div>
          
          {/* Tentacles */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="w-3 h-8 bg-gradient-to-b from-purple-600 to-purple-500 rounded-full"
                style={{
                  transform: `rotate(${(i - 2.5) * 8}deg)`,
                  transformOrigin: 'top center'
                }}
              ></div>
            ))}
          </div>

          {/* Sparkles */}
          <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-yellow-400 fill-current animate-pulse" />
        </div>

        {/* Speech Bubble */}
        <div className="relative bg-white rounded-3xl shadow-lg p-5 mt-8 border-2 border-purple-200">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 bg-white border-l-2 border-t-2 border-purple-200 rotate-45"></div>
          <h2 className="text-xl font-bold text-center text-gray-800 mb-1">
            ¡Hola! Soy Polly 🐙
          </h2>
          <p className="text-center text-gray-600 text-sm leading-relaxed">
            Basándome en tus preferencias, he encontrado estos restaurantes perfectos para ti. ¡Selecciona los que te gustaría explorar!
          </p>
        </div>
      </div>

      {/* Restaurant Recommendations */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Star className="w-5 h-5 text-purple-600" />
          Mis recomendaciones para ti
        </h3>
        
        <div className="space-y-3 pb-4">
          {recommendedRestaurants.map((restaurant) => {
            const isSelected = selectedRestaurants.includes(restaurant.id);
            return (
              <button
                key={restaurant.id}
                onClick={() => toggleRestaurant(restaurant.id)}
                className={`
                  w-full p-4 rounded-2xl border-2 transition-all text-left relative overflow-hidden
                  ${isSelected 
                    ? 'border-purple-500 bg-purple-50 shadow-lg' 
                    : 'border-gray-200 bg-white hover:border-purple-300 hover:shadow-md'
                  }
                `}
              >
                {/* Selection Indicator */}
                {isSelected && (
                  <div className="absolute top-3 right-3">
                    <CheckCircle2 className="w-6 h-6 text-purple-600 fill-current" />
                  </div>
                )}

                {/* Restaurant Info */}
                <div className="pr-8">
                  <h4 className="font-bold text-gray-800 mb-1">{restaurant.name}</h4>
                  <p className="text-sm text-gray-600 mb-2">{restaurant.description}</p>
                  
                  {/* Details */}
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm font-medium text-gray-700">{restaurant.rating}</span>
                    </div>
                    <span className="text-sm text-gray-500">{restaurant.type}</span>
                    <span className="text-sm font-medium text-gray-600">{restaurant.priceLevel}</span>
                  </div>

                  {/* Reason Badge */}
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-100 rounded-full">
                    <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                    <span className="text-xs font-medium text-purple-700">{restaurant.reason}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Action */}
      <div className="p-6 border-t border-gray-100 bg-white">
        <div className="mb-3 text-center">
          <span className="text-sm text-gray-600">
            {selectedRestaurants.length > 0 
              ? `${selectedRestaurants.length} ${selectedRestaurants.length === 1 ? 'restaurante seleccionado' : 'restaurantes seleccionados'}`
              : 'Selecciona al menos un restaurante'
            }
          </span>
        </div>
        <button
          onClick={handleContinue}
          className="w-full bg-gradient-to-r from-purple-500 to-purple-600 text-white py-4 rounded-2xl font-semibold shadow-lg hover:shadow-xl hover:from-purple-600 hover:to-purple-700 transition-all active:scale-[0.98]"
        >
          Continuar al mapa
        </button>
      </div>
    </div>
  );
}
