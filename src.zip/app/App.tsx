import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { PreferencesScreen } from './components/PreferencesScreen';
import { LoginPromptScreen } from './components/LoginPromptScreen';
import { RecommendationsScreen } from './components/RecommendationsScreen';
import { MapScreen } from './components/MapScreen';

type Screen = 'preferences' | 'loginPrompt' | 'login' | 'register' | 'recommendations' | 'map';

interface UserPreferences {
  foodType: string[];
  budget: string;
  placeType: string[];
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('preferences');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [preferences, setPreferences] = useState<UserPreferences>({
    foodType: [],
    budget: '',
    placeType: []
  });
  const [selectedRestaurants, setSelectedRestaurants] = useState<number[]>([]);

  const handlePreferencesComplete = (prefs: UserPreferences) => {
    setPreferences(prefs);
    setCurrentScreen('loginPrompt');
  };

  const handleLoginPromptContinue = () => {
    setCurrentScreen('login');
  };

  const handleSkipLogin = () => {
    setCurrentScreen('recommendations');
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentScreen('recommendations');
  };

  const handleRegister = () => {
    setIsAuthenticated(true);
    setCurrentScreen('recommendations');
  };

  const handleContinueFromRecommendations = (restaurants: number[]) => {
    setSelectedRestaurants(restaurants);
    setCurrentScreen('map');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentScreen('preferences');
    setPreferences({ foodType: [], budget: '', placeType: [] });
    setSelectedRestaurants([]);
  };

  return (
    <div className="size-full bg-gray-50 flex items-center justify-center">
      {/* Mobile container */}
      <div className="w-full max-w-md h-full max-h-[844px] bg-white shadow-2xl rounded-3xl overflow-hidden relative">
        {currentScreen === 'preferences' && (
          <PreferencesScreen 
            onComplete={handlePreferencesComplete}
          />
        )}
        {currentScreen === 'loginPrompt' && (
          <LoginPromptScreen 
            onLogin={handleLoginPromptContinue}
            onSkip={handleSkipLogin}
          />
        )}
        {currentScreen === 'login' && (
          <LoginScreen 
            onLogin={handleLogin}
            onGoToRegister={() => setCurrentScreen('register')}
          />
        )}
        {currentScreen === 'register' && (
          <RegisterScreen 
            onRegister={handleRegister}
            onGoBack={() => setCurrentScreen('login')}
          />
        )}
        {currentScreen === 'recommendations' && (
          <RecommendationsScreen 
            onContinue={handleContinueFromRecommendations}
            preferences={preferences}
          />
        )}
        {currentScreen === 'map' && (
          <MapScreen 
            preferences={preferences}
            onGoToPreferences={() => setCurrentScreen('preferences')}
            onLogout={handleLogout}
          />
        )}
      </div>
    </div>
  );
}